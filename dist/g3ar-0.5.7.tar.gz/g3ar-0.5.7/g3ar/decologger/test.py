#!/usr/bin/env python
#coding:utf-8
"""
  Author:   --<v1ll4n>
  Purpose: Test for decologger
  Created: 2016/12/18
"""

import unittest
import traceback
from .decologger import Decologger




if __name__ == '__main__':
    unittest.main()