#!/usr/bin/env python
#coding:utf-8
"""
  Author:   --<v1ll4n>
  Purpose: TestForDictParser
  Created: 2016/12/16
"""

import unittest
from .dict_parser import *




if __name__ == '__main__':
    unittest.main()